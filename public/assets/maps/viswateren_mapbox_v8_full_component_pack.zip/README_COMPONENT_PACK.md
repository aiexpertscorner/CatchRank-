# Viswateren Mapbox v8 component pack

Deze pack bevat:
- production-ready GeoJSON/CSV/JSON bronnen in `public/mapdata`
- een directe React/Vite component in `src/components/maps/ViswaterenMapboxV8.tsx`
- een demo page in `src/pages/ViswaterenMapDemo.tsx`

## Install

Zorg dat je project `mapbox-gl` gebruikt:

```bash
npm i mapbox-gl
```

## Env

Zet in je `.env`:

```env
VITE_MAPBOX_TOKEN=je_mapbox_token_hier
```

## Gebruik

Importeer de component:

```tsx
import ViswaterenMapboxV8 from './components/maps/ViswaterenMapboxV8';

<ViswaterenMapboxV8 mapboxToken={import.meta.env.VITE_MAPBOX_TOKEN} />
```

## Wat zit er in de kaart

- Provincie polygons
- Gemeente polygons
- Plaats / PC4 punten
- Geclusterde viswaterpunten
- Popups met sessievelden zoals nacht, schuilmiddel en 3e hengel
- Midwest toggle voor snelle focusweergave

## Belangrijkste properties in de waterlaag

- `map_title_v8`
- `map_subtitle_v8`
- `municipality_final_v8`
- `province_final_v8`
- `place_final_v8`
- `pc4_final_v8`
- `night_status_final_v8`
- `shelter_status_final_v8`
- `third_rod_status_final_v8`
- `session_triplet_v8`
- `record_quality_class_v8`
- `mapbox_sort_key_v8`

## Aanbevolen folderplaatsing

Kopieer `public/mapdata` naar je Vite `public` map.
Daarna kun je de component direct gebruiken.
