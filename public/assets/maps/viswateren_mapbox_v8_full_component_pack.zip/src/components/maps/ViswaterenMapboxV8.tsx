import React, { useEffect, useMemo, useRef, useState } from 'react';
import mapboxgl, { GeoJSONSource, LngLatBoundsLike, Map as MapboxMap } from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

mapboxgl.accessToken = '';

type ToggleState = {
  provinces: boolean;
  municipalities: boolean;
  places: boolean;
  waters: boolean;
  midwestOnly: boolean;
};

export interface ViswaterenMapboxV8Props {
  mapboxToken: string;
  className?: string;
  initialCenter?: [number, number];
  initialZoom?: number;
  useMidwestSources?: boolean;
  fitToNetherlands?: boolean;
  waterSourceUrl?: string;
  waterMidwestSourceUrl?: string;
  municipalitySourceUrl?: string;
  municipalityMidwestSourceUrl?: string;
  provinceSourceUrl?: string;
  placeSourceUrl?: string;
  placeMidwestSourceUrl?: string;
}

const DEFAULT_TOGGLES: ToggleState = {
  provinces: true,
  municipalities: true,
  places: true,
  waters: true,
  midwestOnly: false,
};

const NL_BOUNDS: LngLatBoundsLike = [
  [3.1, 50.7],
  [7.4, 53.7],
];

function buildPopupHtml(props: Record<string, any>) {
  const chips = [
    props.night_status_final_v8 ? `🌙 ${props.night_status_final_v8}` : null,
    props.shelter_status_final_v8 ? `⛺ ${props.shelter_status_final_v8}` : null,
    props.third_rod_status_final_v8 ? `3️⃣ ${props.third_rod_status_final_v8}` : null,
  ].filter(Boolean);

  const species = [
    props.top1_species_general,
    props.top2_species_general,
    props.top3_species_general,
  ].filter(Boolean).join(' • ');

  return `
    <div style="min-width:240px;max-width:340px;font-family:Inter,system-ui,sans-serif;">
      <div style="font-size:15px;font-weight:700;margin-bottom:4px;">${props.map_title_v8 || 'Viswater'}</div>
      <div style="font-size:12px;opacity:0.8;margin-bottom:8px;">${props.map_subtitle_v8 || ''}</div>
      ${chips.length ? `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px;">${chips.map(c => `<span style="font-size:11px;padding:4px 6px;border-radius:999px;background:#eef2f7;">${c}</span>`).join('')}</div>` : ''}
      ${props.water_type ? `<div style="font-size:12px;margin-bottom:4px;"><strong>Type:</strong> ${props.water_type}</div>` : ''}
      ${species ? `<div style="font-size:12px;margin-bottom:4px;"><strong>Soorten:</strong> ${species}</div>` : ''}
      ${props.authority ? `<div style="font-size:12px;margin-bottom:4px;"><strong>Authority:</strong> ${props.authority}</div>` : ''}
      ${props.record_quality_class_v8 ? `<div style="font-size:12px;margin-bottom:4px;"><strong>Kwaliteit:</strong> ${props.record_quality_class_v8}</div>` : ''}
      ${props.source_pdf_page ? `<div style="font-size:12px;"><strong>PDF pagina:</strong> ${props.source_pdf_page}</div>` : ''}
    </div>
  `;
}

function addOrUpdateFilter(map: MapboxMap, sourceId: string, layerIds: string[], enabled: boolean) {
  layerIds.forEach((id) => {
    if (map.getLayer(id)) {
      map.setLayoutProperty(id, 'visibility', enabled ? 'visible' : 'none');
    }
  });
}

export default function ViswaterenMapboxV8({
  mapboxToken,
  className,
  initialCenter = [5.2, 52.15],
  initialZoom = 6.8,
  useMidwestSources = false,
  fitToNetherlands = true,
  waterSourceUrl = '/mapdata/viswateren_mapbox_water_points_final_v8.geojson',
  waterMidwestSourceUrl = '/mapdata/viswateren_mapbox_water_points_midwest_final_v8.geojson',
  municipalitySourceUrl = '/mapdata/viswateren_mapbox_municipality_polygons_final_v8.geojson',
  municipalityMidwestSourceUrl = '/mapdata/viswateren_mapbox_municipality_polygons_midwest_final_v8.geojson',
  provinceSourceUrl = '/mapdata/viswateren_mapbox_province_polygons_final_v8.geojson',
  placeSourceUrl = '/mapdata/viswateren_mapbox_place_points_final_v8.geojson',
  placeMidwestSourceUrl = '/mapdata/viswateren_mapbox_place_points_midwest_final_v8.geojson',
}: ViswaterenMapboxV8Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<MapboxMap | null>(null);
  const [toggles, setToggles] = useState<ToggleState>({
    ...DEFAULT_TOGGLES,
    midwestOnly: useMidwestSources,
  });

  const sourceUrls = useMemo(() => ({
    water: toggles.midwestOnly ? waterMidwestSourceUrl : waterSourceUrl,
    municipality: toggles.midwestOnly ? municipalityMidwestSourceUrl : municipalitySourceUrl,
    province: provinceSourceUrl,
    place: toggles.midwestOnly ? placeMidwestSourceUrl : placeSourceUrl,
  }), [toggles.midwestOnly, waterMidwestSourceUrl, waterSourceUrl, municipalityMidwestSourceUrl, municipalitySourceUrl, provinceSourceUrl, placeMidwestSourceUrl, placeSourceUrl]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    mapboxgl.accessToken = mapboxToken;

    const map = new mapboxgl.Map({
      container: containerRef.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: initialCenter,
      zoom: initialZoom,
      attributionControl: true,
    });
    mapRef.current = map;

    map.addControl(new mapboxgl.NavigationControl(), 'top-right');
    map.addControl(new mapboxgl.ScaleControl({ maxWidth: 120, unit: 'metric' }));

    map.on('load', () => {
      if (fitToNetherlands) {
        map.fitBounds(NL_BOUNDS, { padding: 30, duration: 0 });
      }

      map.addSource('provinces', {
        type: 'geojson',
        data: sourceUrls.province,
      });
      map.addLayer({
        id: 'provinces-fill',
        type: 'fill',
        source: 'provinces',
        paint: {
          'fill-color': '#dbe7f0',
          'fill-opacity': 0.14,
        },
      });
      map.addLayer({
        id: 'provinces-line',
        type: 'line',
        source: 'provinces',
        paint: {
          'line-color': '#7b8794',
          'line-width': 1,
          'line-opacity': 0.4,
        },
      });

      map.addSource('municipalities', {
        type: 'geojson',
        data: sourceUrls.municipality,
      });
      map.addLayer({
        id: 'municipalities-fill',
        type: 'fill',
        source: 'municipalities',
        paint: {
          'fill-color': [
            'case',
            ['==', ['get', 'midwest_focus_v8'], true],
            '#d6eadf',
            '#e5e7eb',
          ],
          'fill-opacity': 0.18,
        },
      });
      map.addLayer({
        id: 'municipalities-line',
        type: 'line',
        source: 'municipalities',
        paint: {
          'line-color': '#6b7280',
          'line-width': 0.8,
          'line-opacity': 0.45,
        },
      });

      map.addSource('places', {
        type: 'geojson',
        data: sourceUrls.place,
      });
      map.addLayer({
        id: 'place-points-circle',
        type: 'circle',
        source: 'places',
        paint: {
          'circle-radius': [
            'interpolate', ['linear'], ['zoom'],
            6, 2.5,
            10, 4,
            13, 6,
          ],
          'circle-color': [
            'case',
            ['==', ['get', 'midwest_focus_v8'], true],
            '#1d4ed8',
            '#64748b',
          ],
          'circle-opacity': 0.65,
          'circle-stroke-width': 1,
          'circle-stroke-color': '#ffffff',
        },
      });

      map.addSource('waters', {
        type: 'geojson',
        data: sourceUrls.water,
        cluster: true,
        clusterMaxZoom: 12,
        clusterRadius: 40,
      });
      map.addLayer({
        id: 'water-points-clusters',
        type: 'circle',
        source: 'waters',
        filter: ['has', 'point_count'],
        paint: {
          'circle-color': '#0f766e',
          'circle-radius': [
            'step', ['get', 'point_count'],
            14,
            10, 18,
            50, 24,
            150, 30,
          ],
          'circle-opacity': 0.82,
        },
      });
      map.addLayer({
        id: 'water-points-cluster-count',
        type: 'symbol',
        source: 'waters',
        filter: ['has', 'point_count'],
        layout: {
          'text-field': ['get', 'point_count_abbreviated'],
          'text-size': 12,
          'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'],
        },
        paint: {
          'text-color': '#ffffff',
        },
      });
      map.addLayer({
        id: 'water-points-circle',
        type: 'circle',
        source: 'waters',
        filter: ['all', ['!', ['has', 'point_count']], ['!=', ['get', 'is_bad_entry'], true]],
        paint: {
          'circle-radius': [
            'interpolate', ['linear'], ['zoom'],
            6, 3,
            10, 5,
            14, 7,
          ],
          'circle-color': [
            'match',
            ['get', 'night_allowed_final_v8'],
            true, '#16a34a',
            false, '#ef4444',
            '#f59e0b'
          ],
          'circle-stroke-width': 1,
          'circle-stroke-color': '#ffffff',
          'circle-opacity': 0.9,
        },
      });

      map.on('click', 'water-points-clusters', (e) => {
        const features = map.queryRenderedFeatures(e.point, { layers: ['water-points-clusters'] });
        const clusterId = features[0]?.properties?.cluster_id;
        const source = map.getSource('waters') as GeoJSONSource;
        source.getClusterExpansionZoom(clusterId, (err, zoom) => {
          if (err || !features[0]) return;
          map.easeTo({ center: (features[0].geometry as any).coordinates, zoom });
        });
      });

      map.on('click', 'water-points-circle', (e) => {
        const feature = e.features?.[0];
        if (!feature || feature.geometry.type !== 'Point') return;
        const coordinates = [...feature.geometry.coordinates] as [number, number];
        const props = feature.properties || {};
        new mapboxgl.Popup({ offset: 12 })
          .setLngLat(coordinates)
          .setHTML(buildPopupHtml(props))
          .addTo(map);
      });

      map.on('click', 'place-points-circle', (e) => {
        const feature = e.features?.[0];
        if (!feature || feature.geometry.type !== 'Point') return;
        const props = feature.properties || {};
        const coordinates = [...feature.geometry.coordinates] as [number, number];
        new mapboxgl.Popup({ offset: 10 })
          .setLngLat(coordinates)
          .setHTML(`
            <div style="font-family:Inter,system-ui,sans-serif;min-width:220px;">
              <div style="font-size:15px;font-weight:700;margin-bottom:4px;">${props.map_title_v8 || props.Plaatsnaam || 'Plaats'}</div>
              <div style="font-size:12px;opacity:0.8;margin-bottom:8px;">${props.map_subtitle_v8 || ''}</div>
              <div style="font-size:12px;"><strong>PC4:</strong> ${props.pc4 || '-'}</div>
              <div style="font-size:12px;"><strong>Gemeente:</strong> ${props.Gemeente || '-'}</div>
              <div style="font-size:12px;"><strong>Gekoppelde wateren:</strong> ${props.linked_water_count || 0}</div>
            </div>
          `)
          .addTo(map);
      });

      ['water-points-circle', 'water-points-clusters', 'place-points-circle'].forEach((id) => {
        map.on('mouseenter', id, () => {
          map.getCanvas().style.cursor = 'pointer';
        });
        map.on('mouseleave', id, () => {
          map.getCanvas().style.cursor = '';
        });
      });
    });

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, [fitToNetherlands, initialCenter, initialZoom, mapboxToken, sourceUrls]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !map.isStyleLoaded()) return;
    const provinces = ['provinces-fill', 'provinces-line'];
    const municipalities = ['municipalities-fill', 'municipalities-line'];
    const places = ['place-points-circle'];
    const waters = ['water-points-circle', 'water-points-clusters', 'water-points-cluster-count'];
    addOrUpdateFilter(map, 'provinces', provinces, toggles.provinces);
    addOrUpdateFilter(map, 'municipalities', municipalities, toggles.municipalities);
    addOrUpdateFilter(map, 'places', places, toggles.places);
    addOrUpdateFilter(map, 'waters', waters, toggles.waters);
  }, [toggles]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !map.isStyleLoaded()) return;
    const waterSource = map.getSource('waters') as GeoJSONSource | undefined;
    const municipalitySource = map.getSource('municipalities') as GeoJSONSource | undefined;
    const placeSource = map.getSource('places') as GeoJSONSource | undefined;
    if (waterSource) waterSource.setData(sourceUrls.water);
    if (municipalitySource) municipalitySource.setData(sourceUrls.municipality);
    if (placeSource) placeSource.setData(sourceUrls.place);
  }, [sourceUrls]);

  return (
    <div className={className} style={{ display: 'grid', gridTemplateRows: 'auto 1fr', gap: 12, height: '100%' }}>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {[
          ['provinces', 'Provincies'],
          ['municipalities', 'Gemeenten'],
          ['places', 'Plaatsen / PC4'],
          ['waters', 'Viswateren'],
          ['midwestOnly', 'Midwest only'],
        ].map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setToggles((prev) => ({ ...prev, [key]: !prev[key as keyof ToggleState] }))}
            style={{
              border: '1px solid #cbd5e1',
              background: toggles[key as keyof ToggleState] ? '#0f172a' : '#ffffff',
              color: toggles[key as keyof ToggleState] ? '#ffffff' : '#0f172a',
              padding: '8px 12px',
              borderRadius: 999,
              fontSize: 12,
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            {label}
          </button>
        ))}
      </div>
      <div ref={containerRef} style={{ width: '100%', height: '100%', minHeight: 560, borderRadius: 18, overflow: 'hidden' }} />
    </div>
  );
}
