import React from 'react';
import ViswaterenMapboxV8 from '../components/maps/ViswaterenMapboxV8';

export default function ViswaterenMapDemo() {
  return (
    <div style={{ padding: 16, height: '100vh', boxSizing: 'border-box' }}>
      <ViswaterenMapboxV8
        mapboxToken={import.meta.env.VITE_MAPBOX_TOKEN}
        useMidwestSources={true}
      />
    </div>
  );
}
