# Viswateren Mapbox final v8

Gebaseerd op:
- v7 waterdataset
- `townships.geojson`
- `provinces.geojson`
- PC4 plaatsnaam tabel
- postcode polygon JSON sample

## Kernbestanden
- `viswateren_mapbox_water_points_final_v8.geojson` - alle waterpunten
- `viswateren_mapbox_water_points_midwest_final_v8.geojson` - Midwest focus waterpunten
- `viswateren_mapbox_municipality_polygons_final_v8.geojson` - gemeente polygonlaag
- `viswateren_mapbox_municipality_polygons_midwest_final_v8.geojson` - Midwest gemeente polygonlaag
- `viswateren_mapbox_province_polygons_final_v8.geojson` - provincie polygonlaag
- `viswateren_mapbox_place_points_final_v8.geojson` - plaats/PC4 puntenlaag
- `viswateren_mapbox_place_points_midwest_final_v8.geojson` - Midwest plaats/PC4 puntenlaag
- `viswateren_mapbox_postcode_polygons_sample_final_v8.geojson` - postcode polygon sample (beperkte dekking)
- `viswateren_mapbox_sources_layers_final_v8.json` - source/layer hints voor Mapbox

## Midwest
- water rows Midwest: 497
- Midwest-West water rows: 440
- Midwest-Oost water rows: 57
- place rows Midwest: 648
- municipality polygons Midwest: 67

## Opmerking
De aangeleverde postcode polygon JSON bevat 24 features en lijkt geen landelijke dekking te hebben. Daarom is de landelijke plaatslaag in v8 hoofdzakelijk een puntenlaag.
